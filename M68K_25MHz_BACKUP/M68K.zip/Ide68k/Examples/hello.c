/* HELLO.C  -  The mother of all C programs */

/* This program can be compiled by loading hello.prj in the
 * "Project|Open project" menu. It displays the well-known string
 * "Hello, world!".
 *
 * Author: Kernighan & Ritchie
*/

#include <stdio.h>

void main()
{
    printf("Hello world!\n");
}
