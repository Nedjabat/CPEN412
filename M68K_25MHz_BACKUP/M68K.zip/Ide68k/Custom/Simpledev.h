// Simpledev.h - A simple I/O device library for Visual68K - Header file
// Peter J. Fondse (c) 2002

#define IDC_PORT_A    101
#define IDC_PORT_B    102
#define IDC_PORT_C    201
#define IDC_INT5      301
#define IDC_INT6      302
